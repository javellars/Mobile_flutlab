package com.example.entrega1_livraria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
