//import 'package:aula_5_exercicio/view/navigation/bottomnavigation_layout.dart';
import 'package:aula_5_exercicio/bloc/chat_bloc.dart';
import 'package:aula_5_exercicio/view/chat_screen.dart';
//import 'package:aula_5_exercicio/view/navigation/bottomnavigation_layout.dart';
//import 'package:aula_5_exercicio/view/navigation/custom_layout.dart';
import 'package:aula_5_exercicio/view/navigation/drawer_layout.dart';
//import 'package:aula_5_exercicio/view/navigation/tabbar_layout.dart';
//import 'package:aula_5_exercicio/view/navigation/custom_layout.dart';
//import 'package:aula_5_exercicio/view/navigation/tabbar_layout.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/auth_bloc.dart';
import 'bloc/manage_bloc.dart';
import 'bloc/profile_bloc.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Sala de Aula 04';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //home: const CustomLayout(),
      //home: const TabBarLayout(),
      //home: const BottomNavigationLayout(),
      home: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (_) => AuthBloc(),
          ),
          BlocProvider(
            create: (_) => ProfileBloc(),
          ),
          BlocProvider(
            create: (_) => ChatBloc(),
          ),
          BlocProvider(
            //os dois pontos é pra ele n ficar null quando troca de página
            create: (_) => ManageBloc()..add(GetNoteListEvent()),
          ),
        ],
        child: const DrawerLayout(),
      ),
    );
  }
}
