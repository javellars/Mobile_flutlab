import 'dart:async';

import 'package:dio/dio.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../model/note.dart';

class RestProvider {
  static RestProvider helper = RestProvider._createInstance();

  RestProvider._createInstance();
  Dio _dio = Dio();

// aqui é usando o firebase
  //String prefixUrl =
  //    "https://si700-1s2024-9fae7-default-rtdb.firebaseio.com/notes/";
  //String suffixUrl = ".json";

//aqui ele tá usando o replit
  String prefixUrl =
      "https://2eb41c9d-5db1-4f21-a743-cfd06c6264a0-00-2clstisa074ee.worf.replit.dev/notes/";
  String suffixUrl = "";

  Future<Note> getNote(noteId) async {
    Response response = await _dio.get(prefixUrl + noteId + "/" + suffixUrl);
    return Note.fromMap(response.data);
  }
  //o response.data é o map

  Future<int> insertNote(Note note) async {
    await _dio.post(
      prefixUrl + suffixUrl,
      data: note.toMap(),
    );
    return 42;
  }

  Future<int> deletetNote(noteId) async {
    await _dio.delete(prefixUrl + noteId + "/" + suffixUrl);
    return 42;
  }

  Future<int> updatetNote(noteId, Note note) async {
    await _dio.put(prefixUrl + noteId + "/" + suffixUrl, data: note.toMap());
    return 42;
  }

  Future<List<Note>> getNoteList() async {
    Response response = await _dio
        .get(prefixUrl + suffixUrl); //responde vai devolver todos os dados

    List<Note> noteCollection = [];
    print(response.data);
    try {
      response.data.forEach((key, value) {
        //colocando key passa a iterar sobre um dicionario
        Note note = Note.fromMap(value);
        note.noteId = key;
        //noteCollection.insertNoteOfId(value["id"].toString(), note);

        noteCollection.add(note);
      });
    } catch (e) {
      print("ocorreu um erro!");
    }
    print(noteCollection);
    return noteCollection;
  }
/*Parte da Stream*/

  StreamController _controller = StreamController();

  Stream get stream {
    Socket socket = io(
        "https://2eb41c9d-5db1-4f21-a743-cfd06c6264a0-00-2clstisa074ee.worf.replit.dev",
        OptionBuilder().setTransports(['websocket']) // for Flutter or Dart VM
            .build());

//o on fala que no caso de server information, ele envia isso aqui como dados(o que tá ai embaixo)
    socket.on('server_information', (data) {
      /*
       O servidor nos informa o dado que foi modificado.
      */
      //coleta esses dados aqui
      String noteId = data["noteId"].toString();
      String title = data["title"];
      String description = data["description"];

      // Vamos assumir que "title=null" significa uma remoção.
      if (title == "") {
        //notify(noteId, null);
      } else {
        Note note = Note();
        note.noteId = noteId;
        note.title = title;
        note.description = description;
        _controller.sink.add([noteId, note]);
        // notify(noteId, note);
      }
    });
    return _controller.stream;
  }
}
