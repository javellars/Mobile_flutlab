import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:pusher_channels_flutter/pusher_channels_flutter.dart';

class PusherProvider {
  //uma forma de fazer com _
  //PusherProvider._(); //construtor privado - ninguem instancia essa classe fora desse arquivo
  static PusherProvider helper = PusherProvider
      ._createInstance(); //helper - indica que está usando singleton

  //Construtor Privado
  PusherProvider._createInstance() {
    initPusher();
  }

  PusherChannelsFlutter pusher = PusherChannelsFlutter.getInstance();

  //String app_id = "1793734";
  String key = "bb676536eff40826becb";
  String cluster = "us2";
  //String secret = "de4510da658ac2b6e53e"; - proxima aula
  String channel = "private-channel";
  String event = "client-event";

  initPusher() async {
    try {
      await pusher.init(
          apiKey: key,
          cluster: cluster,
          //onConnectionStateChange: onConnectionStateChange,
          onError: onError,
          onSubscriptionSucceeded: onSubscriptionSucceeded,
          onEvent: onEvent,
          onSubscriptionError: onSubscriptionError,
          onDecryptionFailure: onDecryptionFailure,
          onMemberAdded: onMemberAdded,
          onMemberRemoved: onMemberRemoved,
          onSubscriptionCount: onSubscriptionCount,
          // authEndpoint: "<Your Authendpoint Url>",
          onAuthorizer: onAuthorizer);
      await pusher.subscribe(channelName: channel);
      await pusher.connect();
    } catch (e) {
      log("ERROR: $e");
    }
  }

  void onError(String message, int? code, dynamic e) {
    log("onError: $message code: $code exception: $e");
  }

  void onEvent(PusherEvent event) {
    log("onEvent: $event");
    if (event.data != null) {
      _notify(event.data["message"].toString());
    }
  }

  void onSubscriptionSucceeded(String channelName, dynamic data) {
    log("onSubscriptionSucceeded: $channelName data: $data");
    final me = pusher.getChannel(channelName)?.me;
    log("Me: $me");
  }

  void onSubscriptionError(String message, dynamic e) {
    log("onSubscriptionError: $message Exception: $e");
  }

  void onDecryptionFailure(String event, String reason) {
    log("onDecryptionFailure: $event reason: $reason");
  }

  void onMemberAdded(String channelName, PusherMember member) {
    log("onMemberAdded: $channelName user: $member");
  }

  void onMemberRemoved(String channelName, PusherMember member) {
    log("onMemberRemoved: $channelName user: $member");
  }

  void onSubscriptionCount(String channelName, int subscriptionCount) {
    log("onSubscriptionCount: $channelName subscriptionCount: $subscriptionCount");
  }

  dynamic onAuthorizer(
    String channelName,
    String socketId,
    dynamic options,
  ) async {
    String authUrl =
        "https://7e2b47c7-01ad-4fb2-9a80-5059affbfb94-00-x64c8q7knsb3.janeway.replit.dev/pusher/auth";

    var result = await http.post(
      Uri.parse(authUrl),
      headers: {
        'Content-Type': 'application/json',
      },
      body: json.encode({'socket_id': socketId, 'channel_name': channel}),
    );
    print(result.body);
    return jsonDecode(result.body);
  }

  pushMessage(String message) {
    pusher.trigger(PusherEvent(
      channelName: channel,
      eventName: event,
      data: '{"Mesage": "$message"}',
    ));
  }

  /*
  Stream

   */

  final StreamController<String> _controller = StreamController<String>();

  Stream get stream {
    return _controller.stream;
  }

  //
  _notify(String message) {
    _controller.sink.add(message);
  }
}
