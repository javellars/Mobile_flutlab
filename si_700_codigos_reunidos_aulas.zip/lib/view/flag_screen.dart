import 'package:flutter/material.dart';
import '../model/flag.dart';

class FlagScreen extends StatefulWidget {
  const FlagScreen({super.key});

  @override
  _FlagScreenState createState() => _FlagScreenState();
}

class _FlagScreenState extends State<FlagScreen> {
  final Flags flags = Flags();
  int aux = 0; //auxiliar
  int attemptRest = 3; //numero de tentativas que restam
  bool block = false;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text("Qual a bandeira do ${flags.answer}."),
          Text("Tentativas: ${attemptRest}"),
          Expanded(
              child: GridView.count(
            crossAxisCount: 3,
            children: _buildGridTieList(),
          )),
        ],
      ),
    );
  }

  List<Widget> _buildGridTieList() {
    List<Widget> children = [];
    var deck = flags.deck;
    for (var flag in deck) {
      Widget container = Container(
        margin: EdgeInsets.all(8.0),
        color: Colors.blue,
        padding: EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: () {
            setState(() {
              if (attemptRest > 0) {
                attemptRest--;
              }
              if (attemptRest == 0) {
                //para nao aparecer tentativa -1
                aux = -1;
              }
            });

            int index = deck.indexOf(flag);
            String output, titleOutput;
            if (aux < 0 && block == true) {
              titleOutput = "ERRO";
              output =
                  "Não é possível mais jogar essa rodada. Deseja iniciar nova rodada?";
            } else {
              if (flags.checkAnswer(index) && attemptRest >= 0) {
                titleOutput = "ACERTOU";
                output = "Deseja jogar novamente?";
              } else if (attemptRest == 0) {
                titleOutput = "ERROU";
                output =
                    "E suas tentativas acabaram. Deseja iniciar nova rodada?";
              } else {
                titleOutput = "ERROU";
                output =
                    "Mas ainda restam ${attemptRest} tentativas. Deseja jogar novamente?";
              }
            }

            //caixa de alerta
            showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                      title: Text(titleOutput),
                      content: Text(output),
                      actions: [
                        ElevatedButton(
                          onPressed: () {
                            Navigator.of(context)
                                .pop(); //fecha a caixa de diálogo
                            block = true;
                          },
                          child: Text('NÃO'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            if (attemptRest > 0 &&
                                output != "Deseja jogar novamente?") {
                              //quando ainda tiver tentativas
                              Navigator.of(context).pop();
                            } else {
                              flags.resetGame();
                              Navigator.of(context).pop();
                              setState(() {
                                attemptRest = 3;
                                aux = 0;
                                block = false;
                              });
                            }
                          },
                          child: Text('SIM'),
                        ),
                      ]);
                });
          },
          child: Image(image: AssetImage('assets/$flag')),
        ),
      );

      // Adicionar o widget da bandeira à lista de children
      children.add(container);
    }
    return children;
  }
}
