import 'package:flutter/material.dart';

class TopNavigationBar extends StatefulWidget {
  final String title;
  final List rotulos;
  final Function onTap;
  const TopNavigationBar(
      {super.key,
      required this.title,
      required this.rotulos,
      required this.onTap});

  @override
  _TopNavigationBarState createState() => _TopNavigationBarState();
}

class _TopNavigationBarState extends State<TopNavigationBar> {
  getChildren() {
    List<Widget> children = [];
    //asMap permite que criemos uma função anônima com acesso tanto ao conteúdo da lista widget.rotulos quanto aos índices dos elementos.
    widget.rotulos.asMap().forEach((index, element) {
      children.add(TextButton(
        onPressed: () {
          widget.onTap(index, element);
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4.0),
          height: 20,
          width: 20,
          //color: Colors.blue,
          decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.blue),
          child: Text(
            element.toString(),
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ));
    });
    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: getChildren(),
    );
  }
}
