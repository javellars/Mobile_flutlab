import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../model/aluno.dart';

class AlunoCadastroScreen extends StatefulWidget {
  const AlunoCadastroScreen({Key? key}) : super(key: key);

  @override
  State<AlunoCadastroScreen> createState() => _AlunoCadastroScreenState();
}

class _AlunoCadastroScreenState extends State<AlunoCadastroScreen> {
  List<Aluno> _alunosCadastrados = [];
  String? _nomeAluno;
  String? _sexoAluno;
  int? _raAluno;
  DateTime? _dataNascimentoAluno;
  //chave de formulário para gerenciar o estado do formulário
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  void adicionarAluno() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState?.save();

      Aluno novoAluno = Aluno(
          dataNascimento: _dataNascimentoAluno!,
          nome: _nomeAluno!,
          ra: _raAluno!,
          sexo: _sexoAluno!);

      setState(() {
        _alunosCadastrados.add(novoAluno);
      });
    }
  }

  final List<DropdownMenuItem<String>> _sexoOptions = [
    DropdownMenuItem(value: "Masculino", child: Text("Masculino")),
    DropdownMenuItem(value: "Feminino", child: Text("Feminino")),
    DropdownMenuItem(value: "Outros", child: Text("Outros")),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
      children: [
        Expanded(
            child: ListView.builder(
          itemCount: _alunosCadastrados.length,
          itemBuilder: (context, index) {
            Aluno aluno = _alunosCadastrados[index];
            return ListTile(
              title: Text(aluno.nome),
              subtitle: Text(aluno.ra.toString()),
            );
          },
        )),
        Form(
          key: _formKey, // Associando a chave do formulário
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Nome do Aluno'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o nome do aluno';
                  }
                  return null;
                },
                onSaved: (value) {
                  _nomeAluno = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'RA'),
                keyboardType: TextInputType.number, // Teclado numérico
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o RA do aluno';
                  }
                  return null;
                },
                onSaved: (value) {
                  _raAluno = int.parse(value!);
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                    labelText: _dataNascimentoAluno != null
                        ? _dataNascimentoAluno.toString()
                        : 'Data de Nascimento'),
                readOnly:
                    true, // Impede a edição direta e a abertura do teclado
                onTap: () async {
                  // Fecha o teclado virtual, se aberto
                  FocusScope.of(context).requestFocus(new FocusNode());

                  // Chama o DatePickerDialog
                  final DateTime? pickedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(1900),
                    lastDate: DateTime.now(),
                  );
                  // Se uma data foi escolhida, atualiza o estado
                  if (pickedDate != null) {
                    setState(() {
                      _dataNascimentoAluno = pickedDate;
                    });
                  }
                },
                validator: (value) {
                  if (_dataNascimentoAluno == null) {
                    return 'Por favor, selecione uma data';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                value: _sexoAluno,
                hint: Text("Selecione o sexo"),
                onChanged: (value) => setState(() => _sexoAluno = value),
                onSaved: (value) => _sexoAluno = value,
                validator: (value) =>
                    value == null ? 'Campo obrigatório' : null,
                items: _sexoOptions,
              ),
              ElevatedButton(
                onPressed: adicionarAluno,
                child: Text('Adicionar Aluno'),
              ),
            ],
          ),
        )
      ],
    ));
  }
}
