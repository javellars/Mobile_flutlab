import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/manage_bloc.dart';
import '../model/note.dart';

class AddNote extends StatelessWidget {
  AddNote({Key? key}) : super(key: key);

  final GlobalKey<FormState> formKey = GlobalKey();
  final Note note = Note();

  @override
  Widget build(BuildContext context) {
    return Form(
        //usa o Form ou Onchanged ou Controller
        key: formKey, //assume que tera um validator e um onsaved
        child: Column(
          children: [
            tituloFormField(),
            descriptionFormField(),
            submitButton(context),
            cancelButton(context),
          ],
        ));
  }

  Widget tituloFormField() {
    return BlocBuilder<ManageBloc, ManageState>(builder: (context, state) {
      String initialValue = "note.description";
      if (state is UpdateState) {
        List<Note> noteList = state.noteList;
        String noteId = state.noteId;
        for (Note note in noteList) {
          if (note.noteId == noteId) {
            initialValue = note.description;
          }
        }
      }
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          initialValue: "note.title",
          decoration: InputDecoration(
              labelText: "Título",
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
          validator: (value) {
            if (value!.isEmpty) {
              return "Adicione algum título";
            }
            return null;
          },
          onSaved: (value) {
            note.title = value!;
          },
        ),
      );
    });
  }

  Widget descriptionFormField() {
    return BlocBuilder<ManageBloc, ManageState>(builder: (context, state) {
      String initialValue = "note.description";
      if (state is UpdateState) {
        List<Note> noteList = state.noteList;
        String noteId = state.noteId;
        for (Note note in noteList) {
          if (note.noteId == noteId) {
            initialValue = note.description;
          }
        }
      }
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          initialValue: initialValue,
          decoration: InputDecoration(
              labelText: "Anotação",
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
          validator: (value) {
            if (value!.isEmpty) {
              return "Adicione alguma anotação";
            }
            return null;
          },
          onSaved: (value) {
            note.description = value!;
          },
        ),
      );
    });
  }

  Widget submitButton(context) {
    return ElevatedButton(child: BlocBuilder<ManageBloc, ManageState>(
        builder: (context, ManageState state) {
      if (state is UpdateState) {
        return const Text(
          "Update data",
        );
      } else {
        return const Text(
          "Insert Data",
        );
      }
    }), onPressed: () {
      if (formKey.currentState!.validate()) {
        formKey.currentState!.save();
        BlocProvider.of<ManageBloc>(context).add(SubmitEvent(note: note));

        formKey.currentState!.reset();
      }
    });
  }

  Widget cancelButton(context) {
    return BlocBuilder<ManageBloc, ManageState>(builder: (context, state) {
      if (state is UpdateState) {
        return ElevatedButton(
            onPressed: () {
              BlocProvider.of<ManageBloc>(context).add(UpdateCancel());
            },
            child: const Text("Cancel Update"));
      } else {
        //eu seu que é insert
        return Container();
      }
    });
  }
}
