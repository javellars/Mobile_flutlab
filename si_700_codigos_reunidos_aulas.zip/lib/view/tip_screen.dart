import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../model/tip.dart';

class TipScreen extends StatefulWidget {
  const TipScreen({super.key});

  @override
  _TipScreenState createState() => _TipScreenState();
}

class _TipScreenState extends State<TipScreen> {
  Tip tip =
      Tip.withData(); //novo atributo do tipo Tip (usando o construtor nomeado)

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          TextFormField(
            initialValue: tip.amount,
            keyboardType: TextInputType.number,
            onChanged: (value) {
              setState(() {
                tip.amount = value;
              });
            },
            decoration: const InputDecoration(labelText: 'Valor Total'),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$'))
            ],
          ),
          TextFormField(
            initialValue: tip.numCustomers,
            keyboardType: TextInputType.number,
            onChanged: (value) {
              setState(() {
                tip.numCustomers = value;
              });
            },
            decoration: const InputDecoration(labelText: 'Número de Clientes'),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$'))
            ],
          ),
          InputDecorator(
              decoration:
                  const InputDecoration(labelText: 'Gorjeta Customizada'),
              child: Slider(
                min: 1,
                max: 50,
                value: double.parse(tip.customTip),
                onChanged: (double value) {
                  setState(() {
                    tip.customTip = value.toString();
                  });
                },
              )),
          Table(
            border: TableBorder.all(),
            children: [
              TableRow(children: [
                TableCell(child: Center(child: Text('Descrição'))),
                TableCell(child: Center(child: Text('Valor'))),
              ]),
              TableRow(children: [
                TableCell(child: Text('Gorjeta Padrão')),
                TableCell(child: Text(tip.defaultTippedAmount)),
              ]),
              TableRow(children: [
                TableCell(child: Text('Gorjeta Customizada')),
                TableCell(child: Text(tip.customTippedAmount)),
              ]),
              TableRow(children: [
                TableCell(child: Text('Total (Gorjeta Padrão)')),
                TableCell(child: Text(tip.amountPlusDefaultTippedAmount)),
              ]),
              TableRow(children: [
                TableCell(child: Text('Total (Gorjeta Customizada)')),
                TableCell(child: Text(tip.amountPlusCustomTippedAmount)),
              ]),
              TableRow(children: [
                TableCell(child: Text('Total dividido(Gorjeta Padrão)')),
                TableCell(child: Text(tip.splitAmountPlusDefaultTippedAmount)),
              ]),
              TableRow(children: [
                TableCell(child: Text('Total dividido(Gorjeta Customizada)')),
                TableCell(child: Text(tip.splitAmountPlusCustomTippedAmount)),
              ]),
            ],
          ),
        ],
      ),
    );
  }
}
