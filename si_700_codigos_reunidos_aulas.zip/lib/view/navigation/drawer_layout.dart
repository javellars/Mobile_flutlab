import 'package:aula_5_exercicio/bloc/manage_bloc.dart';
import 'package:aula_5_exercicio/view/chat_screen.dart';
import 'package:aula_5_exercicio/view/bloc_intro_screen.dart';
import 'package:aula_5_exercicio/view/flag_screen.dart';
import 'package:aula_5_exercicio/view/formulario.dart';
import 'package:aula_5_exercicio/view/list_note.dart';
import 'package:aula_5_exercicio/view/tip_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../add_note.dart';
import '../aluno_screen.dart';

//uniao de um drawer com uma list view
class DrawerLayout extends StatefulWidget {
  const DrawerLayout({Key? key}) : super(key: key);

  @override
  State<DrawerLayout> createState() => _DrawerLayoutState();
}

class _DrawerLayoutState extends State<DrawerLayout> {
  int _currentScreen = 5;

  changeScreen(int value) {
    setState(() {
      _currentScreen = value;
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                child: Text("asdf"),
                decoration: BoxDecoration(color: Colors.blue),
              ),
              ListTile(
                  title: Text("Primeira Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(0);
                  }),
              ListTile(
                  title: Text("Segunda Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(1);
                  }),
              ListTile(
                  title: Text("Terceira Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(2);
                  }),
              ListTile(
                  title: Text("Quarta Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(3);
                  }),
              ListTile(
                  title: Text("Quinta Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(4);
                  }),
              ListTile(
                  title: Text("Sexta Tela"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(5);
                  }),
              ListTile(
                  title: BlocBuilder<ManageBloc, ManageState>(
                      builder: (context, state) {
                    if (state is UpdateState) {
                      return Text("Banco de dados - Atualizar");
                    } else {
                      return const Text("Banco de dados -  inserir");
                    }
                  }),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(6);
                  }),
              ListTile(
                  title: Text("Banco de Dados - Lista"),
                  tileColor: Colors.white,
                  onTap: () {
                    changeScreen(7);
                  }),
            ],
          ),
        ),
        appBar: AppBar(
            backgroundColor: Colors.yellow, title: Text("Drawer Layout")),
        body: IndexedStack(
          index: _currentScreen,
          children: [
            TipScreen(),
            FlagScreen(),
            Formulario(),
            AlunoCadastroScreen(),
            BlocIntroScreen(),
            ChatScreen(),
            AddNote(),
            ListNote(),
          ],
        ));
  }
}
