import 'dart:ui';

import 'package:aula_5_exercicio/view/formulario.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../flag_screen.dart';
import '../nav.dart';
import '../tip_screen.dart';

class CustomLayout extends StatefulWidget {
  const CustomLayout({super.key});

  @override
  _CustomLayoutState createState() => _CustomLayoutState();
}

class _CustomLayoutState extends State<CustomLayout> {
  final _pageViewController = PageController(initialPage: 0);
  List<Widget> children = [
    TipScreen(),
    FlagScreen(),
    Formulario(),
    Container(
      color: Colors.red,
    ),
    Container(
      color: Colors.blue,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Demo Click Counter'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TopNavigationBar(
                title: "title",
                rotulos: ["texto1", "texto2", "texto3", "texto4", "texto5"],
                onTap: (index, rotulo) {
                  _pageViewController.jumpToPage(index);
                }),
            Expanded(
              child: ScrollConfiguration(
                behavior:
                    ScrollConfiguration.of(context).copyWith(dragDevices: {
                  PointerDeviceKind.touch,
                  PointerDeviceKind.mouse,
                }),
                child: PageView(
                  controller: _pageViewController,
                  children: children,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
