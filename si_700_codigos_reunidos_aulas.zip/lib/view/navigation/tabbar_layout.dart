import 'package:aula_5_exercicio/view/formulario.dart';
import 'package:flutter/material.dart';

import '../flag_screen.dart';
import '../tip_screen.dart';

//StatelessWidget -> para criar apenas colocar stl
class TabBarLayout extends StatelessWidget {
  const TabBarLayout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, //com 3 opções
      child: Scaffold(
        //usamos para dar o esqueleto da nossa aplicação
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: const Text("Layout com TabBar"),
          bottom: TabBar(tabs: [
            Tab(child: Text("Gorjeta"), icon: Icon(Icons.abc_outlined)),
            Tab(
                child: Text("Bandeiras"),
                icon: Icon(Icons.baby_changing_station)),
            Tab(child: Text("Formulario"), icon: Icon(Icons.access_alarms)),
          ]),
        ),
        body: TabBarView(children: [TipScreen(), FlagScreen(), Formulario()]),
      ),
    );
  }
}
