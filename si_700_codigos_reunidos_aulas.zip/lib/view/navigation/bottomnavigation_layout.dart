import 'package:aula_5_exercicio/view/flag_screen.dart';
import 'package:aula_5_exercicio/view/formulario.dart';
import 'package:aula_5_exercicio/view/tip_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BottomNavigationLayout extends StatefulWidget {
  const BottomNavigationLayout({Key? key}) : super(key: key);

  @override
  State<BottomNavigationLayout> createState() => _BottomNavigationLayoutState();
}

class _BottomNavigationLayoutState extends State<BottomNavigationLayout> {
  int _currentScreen = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Layout com BottomNavigationBar"),
        backgroundColor: Colors.blue,
      ),
      body: IndexedStack(
          index: _currentScreen, //index: 1 - o numero muda a pagina
          children: [TipScreen(), FlagScreen(), Formulario()]),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Gorjeta"),
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Bandeiras"),
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Formulario"),
        ],
        //oneTap captura o gatilho do que foi clicado
        onTap: (value) {
          //vai ter que recever um parâmetro pq vai ser o elemento que foi clicado
          setState(() {
            _currentScreen = value;
          });
        },
        currentIndex: _currentScreen, //para a opção selecionada fique colorida
        fixedColor: Colors.purple, //muda a cor do que está selecionado
      ),
    );
  }
}
