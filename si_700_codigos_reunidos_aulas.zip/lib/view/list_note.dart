import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/manage_bloc.dart';
import '../model/note.dart';

class ListNote extends StatelessWidget {
  ListNote({Key? key}) : super(key: key);

  final List colors = [Colors.orange, Colors.red, Colors.yellow];
  final List icons = [Icons.ac_unit_outlined, Icons.access_alarm_rounded];

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ManageBloc, ManageState>(
      builder: (context, state) {
        List<Note> noteList = [];
        noteList = state.noteList;

        return Column(
          children: [
            Expanded(child: getNoteListView(noteList)),
            ElevatedButton(
                onPressed: () {
                  BlocProvider.of<ManageBloc>(context).add(GetNoteListEvent());
                },
                child: Text("GetNotList"))
          ],
        );
      },
    );
  }

  ListView getNoteListView(List<Note> noteList) {
    return ListView.builder(
        itemCount: noteList.length,
        itemBuilder: (context, position) => ListTile(
              onTap: () {
                //quando achar o ManageBloc ele vai dar um update
                ManageBloc manageBloc = BlocProvider.of<ManageBloc>(context);
                manageBloc.add(UpdateRequest(
                  noteId: noteList[position].noteId,
                ));
              },
              leading: Icon(icons[position % icons.length]),
              trailing: GestureDetector(
                  onTap: () {
                    BlocProvider.of<ManageBloc>(context)
                        .add(DeleteEvent(noteId: noteList[position].noteId));
                  },
                  child: const Icon(Icons.delete)),
              title: Text(noteList[position].title),
              subtitle: Text(noteList[position].description),
            ));
  }
}
