import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/chat_bloc.dart';

class ChatScreen extends StatelessWidget {
  final TextEditingController _textEditingController = TextEditingController();
  ChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          controller: _textEditingController,
        ),
        ElevatedButton(
            onPressed: () {
              //setinha que vai da GUI (interface gráfica) para o Bloc
              BlocProvider.of<ChatBloc>(context)
                  .add(GuiMessageEvent(_textEditingController.text));
            },
            child: const Text("Enviar")),
        Expanded(
            //setinha que vai do Bloc para a GUI (interface gráfica)
            child: BlocBuilder<ChatBloc, String>(builder: (context, state) {
          return Text(state);
        }))
      ],
    );
  }
}
