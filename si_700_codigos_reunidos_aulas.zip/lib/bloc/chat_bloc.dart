import 'package:aula_5_exercicio/provider/pusher_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ChatBloc extends Bloc<ChatEvent, String> {
  ChatBloc() : super('') {
    PusherProvider.helper.stream.listen((event) {
      add(ServerMessageEvent(event.toString()));
    });

    on<ServerMessageEvent>((event, Emitter emit) {
      //chegou pro servidor, só põe na tela
      emit("$state\n${event.message}");
    });

    on<GuiMessageEvent>((event, Emitter emit) {
      //chegou uma mensagem na tela, manda pro servidor e manda pra tela
      PusherProvider.helper.pushMessage(event.message);
      emit("$state\n${event.message}");
    });
  }
}

//Evento
abstract class ChatEvent {
  String message;
  ChatEvent(this.message);
}

class GuiMessageEvent extends ChatEvent {
  GuiMessageEvent(super.message);
}

class ServerMessageEvent extends ChatEvent {
  ServerMessageEvent(super.message);
}
