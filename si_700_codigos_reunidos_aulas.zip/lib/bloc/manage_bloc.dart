import 'package:aula_5_exercicio/provider/rest_provider.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../model/note.dart';

class ManageBloc extends Bloc<ManageEvent, ManageState> {
  ManageBloc() : super(InsertState(noteList: [])) {
    RestProvider.helper.stream.listen((event) {
      //event é a dupla [noteid, note];
      String noteId = event[0];
    });

    on<UpdateRequest>((event, emit) {
      emit(UpdateState(noteId: event.noteId, noteList: state.noteList));
    });

    on<UpdateCancel>((event, emit) {
      emit(InsertState(noteList: state.noteList));
    });

    on<SubmitEvent>((event, emit) {
      if (state is UpdateState) {
        RestProvider.helper.updatetNote(
          (state as UpdateState).noteId,
          event.note,
        );
      } else {
        RestProvider.helper.insertNote(event.note);
      }
    });

    on<DeleteEvent>((event, emit) {
      RestProvider.helper.deletetNote(event.noteId);
    });

    on<GetNoteListEvent>((event, emit) async {
      //como esse List fica dentro do if e else, cabe colocar ele acima do if else, pois se aplica aos dois
      List<Note> noteList = await RestProvider.helper.getNoteList();

      if (state is UpdateState) {
        emit(UpdateState(
            noteId: (state as UpdateState).noteId, noteList: noteList));
      } else {
        emit(InsertState(noteList: noteList));
      }
    });
  }
}

/*

 */
abstract class ManageEvent {}

class SubmitEvent extends ManageEvent {
  Note note;
  SubmitEvent({required this.note});
}

class DeleteEvent extends ManageEvent {
  String noteId;
  DeleteEvent({required this.noteId});
}

class GetNoteListEvent extends ManageEvent {}

//esses dois não executam uma ação, eles mudam de estado
//
class UpdateRequest extends ManageEvent {
  String noteId;
  UpdateRequest({required this.noteId});
}

class UpdateCancel extends ManageEvent {}

/*
Estados
 */
abstract class ManageState {
  List<Note> noteList;

  ManageState({required this.noteList});
}

class InsertState extends ManageState {
  InsertState({required super.noteList});
}

class UpdateState extends ManageState {
  String noteId;
  UpdateState({
    required this.noteId,
    required super.noteList,
  });
}
