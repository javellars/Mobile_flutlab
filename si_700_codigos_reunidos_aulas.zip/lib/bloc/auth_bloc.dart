//conterá toda a lógica relacionada ao estado de autenticação do usuário.
import 'package:flutter_bloc/flutter_bloc.dart';

class AuthBloc extends Bloc<AuthEvent, AuthStatus> {
  AuthBloc() : super(AuthStatus.unauthenticated) {
    on<ToggleAuthEvent>((event, emit) {
      if (state == AuthStatus.authenticated) {
        emit(AuthStatus.unauthenticated);
      } else {
        emit(AuthStatus.authenticated);
      }
    });
  }
}

abstract class AuthEvent {}

class ToggleAuthEvent extends AuthEvent {}

//Estados
enum AuthStatus { authenticated, unauthenticated }
