//Classe Aluno
class Aluno {
  String nome;
  DateTime dataNascimento; //usado para representar datas e horas
  int ra;
  String sexo;

  //Construtor da classe Aluno
  Aluno(
      {required this.nome, //required para indicar que são obrigatórios
      required this.dataNascimento,
      required this.ra,
      required this.sexo});
}
