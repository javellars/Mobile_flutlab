class Note {
  String title = "";
  String description = "";
  String noteId = "";

  Note() {
    title = "";
    description = "";
  }

//construtor passando dados
  Note.withData({title = "", description = ""});

  //vai transformar um json em um map
  Note.fromMap(map) {
    title = map["title"];
    description = map["description"];
  }

  toMap() {
    var map = <String, dynamic>{};
    map["title"] = title;
    map["description"] = description;
    return map;
  }
}
