import 'dart:math';

class Flags {
  final Random _random = Random();
  int _currentCountry = 0;
  final _flags = [
    "Africa/Africa-Cameroon.png",
    "Asia/Asia-Afghanistan.png",
    "Asia/Asia-Armenia.png",
    "Europe/Europe-Croatia.png",
    "Europe/Europe-Denmark.png",
    "Oceania/Oceania-New_Zealand.png",
    "South_America/South_America-Argentina.png",
    "South_America/South_America-Netherlands_Antilles.png",
    "North_America/North_America-Canada.png",
    "North_America/North_America-Costa_Rica.png"
  ];

  Flags() {
    resetGame();
  }

  resetGame() {
    _flags.shuffle();
    _currentCountry = _random.nextInt(6);
  }

  List get deck {
    return _flags.sublist(0, 6);
  }

  String get answer {
    return _flags[_currentCountry].split('-').last.split('.').first;
  }

  bool checkAnswer(int value) {
    return value == _currentCountry;
  }
}
