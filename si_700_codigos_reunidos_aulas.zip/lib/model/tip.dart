class Tip {
  final double _defaultTip = 10; //valor padrão de gorjeta
  double? _customTip; //gorjeta com % personalizada escolhida pelo usuário
  double? _totalAmount; //valor total da conta
  int _numCustomers = 1; //numero de pessoas que irão dividir a conta

  //CONSTRUTORES
  //atribui valor ao customTip
  Tip() {
    _customTip = 10;
  }

  //atribui valores aos atributos customTip e totalAmount
  Tip.withData({double customTip = 10, double totalAmount = 30}) {
    _customTip = customTip;
    _totalAmount = totalAmount;
  }

  //GET E SET
  //retornam String com valores em duas casas decimais
  String get customTip {
    return (_customTip ?? 0).toStringAsFixed(
        2); //customTip retorna zero se o valor em _customTip for null
  }

  String get defaultTip {
    return _defaultTip.toStringAsFixed(2);
  }

  String get amount {
    return (_totalAmount ?? 0).toStringAsFixed(2);
  }

  //get para número de clientes (atividade 01)
  String get numCustomers {
    return _numCustomers.toStringAsFixed(0);
  }

  //retorna o valor da gorjeta usando a porcentagem padrão
  String get defaultTippedAmount {
    return ((_totalAmount ?? 0) * (_defaultTip / 100))
        .toStringAsFixed(2); //valor / 100 para ficar em % ex: 10 -> 0,10
  }

  //retorna a soma do valor consumido pelo usuário e o valor da gorjeta usando a porcentagem padrão (defaultTip)
  String get amountPlusDefaultTippedAmount {
    return ((_totalAmount ?? 0) * (1 + (_defaultTip / 100))).toStringAsFixed(2);
  }

  //retorna o valor da gorjeta usando a porcentagem personalizada
  String get customTippedAmount {
    return ((_totalAmount ?? 0) * (_customTip ?? 0) / 100).toStringAsFixed(2);
  }

  //retorna a soma do valor consumido pelo usuário e o valor da gorjeta usando a porcentagem personalizada (customTip)
  String get amountPlusCustomTippedAmount {
    return ((_totalAmount ?? 0) * (1 + ((_customTip ?? 0) / 100)))
        .toStringAsFixed(2);
  }

  //ATIVIDADE 01
  String get splitDefaultTippedAmount {
    return (((_totalAmount ?? 0) / _numCustomers) * (_defaultTip / 100))
        .toStringAsFixed(2);
  }

  String get splitCustomTippedAmount {
    return (((_totalAmount ?? 0) / _numCustomers) * (_customTip ?? 0) / 100)
        .toStringAsFixed(2);
  }

  String get splitAmountPlusDefaultTippedAmount {
    return (((_totalAmount ?? 0) / _numCustomers) * (1 + (_defaultTip / 100)))
        .toStringAsFixed(2);
  }

  String get splitAmountPlusCustomTippedAmount {
    return (((_totalAmount ?? 0) / _numCustomers) *
            (1 + ((_customTip ?? 0) / 100)))
        .toStringAsFixed(2);
  }

  //Para colocar o valor total da conta e a % personalizada pelo usuário
  set amount(String value) {
    try {
      _totalAmount = double.parse(value);
    } catch (e) {
      _totalAmount = 0;
    }
  }

  set customTip(String value) {
    try {
      _customTip = double.parse(value);
    } catch (e) {
      _customTip = 0;
    }
  }

  //set para número de clientes (atividade 01)
  set numCustomers(String value) {
    try {
      _numCustomers = int.parse(value);
    } catch (e) {
      _numCustomers = 0;
    }
  }
}
