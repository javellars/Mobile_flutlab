package com.example.aula_5_exercicio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
